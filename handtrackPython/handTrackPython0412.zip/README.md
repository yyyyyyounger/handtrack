需安裝 `flask` 和 `flask_cors` 庫

使用 `pip install flask`
使用 `pip install flask_cors`

